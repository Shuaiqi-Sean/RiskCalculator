test_domain <- function() {
  list(
    sendInputMessage = function(id, msg) msg
  )
}